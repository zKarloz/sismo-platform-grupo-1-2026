/** Mapa exclusivo de sismos observados IGP/CENSIS.
 * El catálogo sincronizado alimenta el mapa mensual; los enlaces desde Dashboard
 * abren el popup del evento concreto, incluso si aún no entró a PostgreSQL.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { Circle, CircleMarker, LayerGroup, LayersControl, MapContainer, Polygon, Popup, Rectangle, TileLayer, Tooltip, useMap, useMapEvents } from 'react-leaflet';
import { useLocation, useSearchParams } from 'react-router-dom';
import L from 'leaflet';
import { CalendarClock, ExternalLink, Layers, List, MapPin, RefreshCw, X } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import './mapStyles.css';
import FilterBar from '../../components/analytics/FilterBar';
import AppliedFiltersAside from '../../components/analytics/AppliedFiltersAside';
import { useAnalyticsFilters } from '../../hooks/useAnalyticsFilters';
import { useIGPFeed } from '../../hooks/useIGPFeed';
import { getDashboardOperations, getMapEvents } from '../../services/analytics';
import { IGP_OFFICIAL_URL, peruDate } from '../../services/igp';
import { matchesPeruPeriod, withCurrentPeruMonth } from '../../lib/peruMonth';
import { clusterEpicenters, MAGNITUDE_COLORS, magnitudeColor, magnitudeRadius } from '../../lib/mapClusters';
import { departmentBounds, pointInDepartment, PERU_DEPARTMENTS, type DepartmentBoundary } from '../../lib/peruDepartments';
import { getDepartmentBoundary } from '../../services/departments';
import type { GeoDataset, GeoFeature } from '../../types/analytics';
import type { IGPEvent } from '../../types/igp';

/** Mostrar fechas del rango civil peruano sin convertirlas a otro huso. */
function civilDate(value?: string): string {
  return value ? `${value.slice(8, 10)}/${value.slice(5, 7)}/${value.slice(0, 4)}` : 'Sin límite';
}

/** El mapa solo ajusta todos los puntos cuando no hay un foco solicitado. */
function FitMarkers({ features, focused, defaultCenter, defaultBounds }: {
  features: GeoFeature[];
  focused: boolean;
  defaultCenter?: [number, number];
  defaultBounds?: [[number, number], [number, number]];
}) {
  const map = useMap();
  useEffect(() => {
    if (focused) return;
    const valid = features
      .map(feature => feature.geometry.coordinates)
      .filter(([lon, lat]) => Number.isFinite(lon) && Number.isFinite(lat))
      .map(([lon, lat]) => [lat, lon] as L.LatLngTuple);
    if (valid.length === 0) {
      if (defaultBounds) map.fitBounds(defaultBounds, { maxZoom: 9 });
      else map.setView(defaultCenter ?? [-9.19, -75], defaultCenter ? 7 : 5);
      return;
    }
    if (valid.length === 1) map.setView(valid[0], 8);
    else map.fitBounds(L.latLngBounds(valid).pad(0.15), { maxZoom: 8 });
  }, [features, focused, map, defaultCenter?.[0], defaultCenter?.[1],
      defaultBounds?.[0][0], defaultBounds?.[0][1], defaultBounds?.[1][0], defaultBounds?.[1][1]]);
  return null;
}

/** Misma ficha al pulsar un epicentro y al abrirlo desde Últimos reportes. */
function Epicenter({ feature, focused, liveFallback, autoZoom = false, onClose }: {
  feature: GeoFeature;
  focused: boolean;
  liveFallback: boolean;
  /** Solo enlaces procedentes del Dashboard deben cambiar el zoom. */
  autoZoom?: boolean;
  onClose?: () => void;
}) {
  const map = useMap();
  const markerRef = useRef<L.CircleMarker | null>(null);
  const [longitude, latitude] = feature.geometry.coordinates;
  const event = feature.properties;

  useEffect(() => {
    if (!focused || !markerRef.current) return;
    // Usamos la propia capa Leaflet para abrir exactamente el mismo Popup.
    if (autoZoom) map.setView([latitude, longitude], Math.max(map.getZoom(), 9), { animate: false });
    // Abrir la ficha sin cambiar el nivel de zoom en selecciones del clúster.
    markerRef.current.openPopup();
  }, [focused, autoZoom, latitude, longitude, map]);

  const color = magnitudeColor(event.magnitude);
  return <CircleMarker ref={markerRef} center={[latitude, longitude]}
    radius={magnitudeRadius(event.magnitude)}
    // El color lo decide cada evento, no el tema ni el color de los clústeres.
    pathOptions={{ className: 'sismo-point', color, fillColor: color, weight: focused ? 3 : 2, fillOpacity: 0.95, opacity: 1 }}
    eventHandlers={onClose ? { popupclose: onClose } : undefined}>
    <Popup>
      <div className="space-y-1 text-sm">
        <strong>{event.place || 'Ubicación no publicada'}</strong>
        <p className="flex items-center gap-2">Magnitud:
          <span aria-hidden="true" className="inline-block h-3 w-3 rounded-full border" style={{ backgroundColor: color, borderColor: color }}/>
          {event.magnitude == null ? 'Sin dato' : `${event.magnitude.toFixed(1)} ${event.magnitude_type ?? ''}`}
        </p>
        <p>Profundidad: {event.depth_km == null ? 'Sin dato' : `${event.depth_km.toFixed(1)} km`}</p>
        <p>Latitud: {latitude.toFixed(5)} · Longitud: {longitude.toFixed(5)}</p>
        <p>Fecha/hora Perú: {peruDate(event.occurred_at, true)}</p>
        <p>Fuente: IGP/CENSIS</p>
        {liveFallback && <p>Reporte IGP en vivo, pendiente de confirmar su presencia en el catálogo sincronizado.</p>}
        {event.source_url?.startsWith('https://') && <a href={event.source_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-medium text-blue-700">Ver fuente oficial <ExternalLink size={12}/></a>}
      </div>
    </Popup>
  </CircleMarker>;
}

/** El código oficial permite emparejar los reportes en vivo con los persistidos. */
function asLiveFeature(event: IGPEvent): GeoFeature {
  return {
    type: 'Feature', id: `igp-live-${event.external_id}`,
    geometry: { type: 'Point', coordinates: [event.longitude, event.latitude] },
    properties: {
      external_id: event.external_id, occurred_at: event.occurred_at,
      magnitude: event.magnitude, magnitude_type: event.magnitude_type,
      depth_km: event.depth_km, place: event.place,
      source_url: event.source_url, source_name: event.source_name,
    },
  };
}

/** Agrupación determinista al volver al mismo zoom.
 * El evento seleccionado se dibuja como capa adicional, sin extraerlo de su
 * grupo original: los recuentos no dependen del historial de selecciones.
 * Hover (ratón) y toque (móvil) muestran una vista previa con transición.
 */
function ClusteredMarkers({ features, selectedId, dashboardTargetId, onSelect }: {
  features: GeoFeature[];
  selectedId: string | null;
  dashboardTargetId: string | null;
  onSelect: (externalId: string | null) => void;
}) {
  const map = useMap();
  const [zoom, setZoom] = useState(map.getZoom());
  const [previewKey, setPreviewKey] = useState<string | null>(null);
  const [previewVisible, setPreviewVisible] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useMapEvents({ zoomend: () => setZoom(map.getZoom()) });

  // La cuadrícula se ancla a coordenadas mundiales de Leaflet en cada zoom;
  // seleccionar un sismo nunca cambia los integrantes de los grupos.
  const clusters = useMemo(() => clusterEpicenters(
    features,
    (latitude, longitude) => map.project([latitude, longitude], zoom),
    58,
  ), [features, map, zoom]);
  const selectedFeature = selectedId
    ? features.find(feature => feature.properties.external_id === selectedId)
    : undefined;
  const selectedInGroup = Boolean(selectedFeature && clusters.some(cluster =>
    cluster.events.length > 1 && cluster.events.some(event => event.id === selectedFeature.id)));

  function cancelClose() {
    if (closeTimer.current !== null) {
      clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
  }
  function showPreview(key: string) {
    cancelClose();
    setPreviewKey(key);
    setPreviewVisible(true);
  }
  function scheduleClose(key: string) {
    cancelClose();
    // Permite desplazar el puntero desde el círculo a la ficha flotante.
    closeTimer.current = setTimeout(() => {
      setPreviewVisible(false);
      // Mantener montado durante la animación de salida.
      closeTimer.current = setTimeout(() => {
        setPreviewKey(previous => previous === key ? null : previous);
        closeTimer.current = null;
      }, 160);
    }, 220);
  }
  useEffect(() => () => { if (closeTimer.current !== null) clearTimeout(closeTimer.current); }, []);
  useEffect(() => {
    cancelClose();
    setPreviewVisible(false);
    setPreviewKey(null);
  }, [zoom, features]);

  return <>
    {clusters.map(cluster => cluster.events.length === 1
      ? <Epicenter key={cluster.key} feature={cluster.events[0]}
          focused={cluster.events[0].properties.external_id === selectedId}
          autoZoom={cluster.events[0].properties.external_id === dashboardTargetId}
          onClose={cluster.events[0].properties.external_id === selectedId && selectedId !== dashboardTargetId
            ? () => onSelect(null) : undefined}
          liveFallback={cluster.events[0].id.startsWith('igp-live-')}/>
      : <CircleMarker key={cluster.key} center={[cluster.latitude, cluster.longitude]}
          radius={19} pathOptions={{ className: 'sismo-cluster-circle', color: '#155e75', fillColor: '#155e75', weight: 2, fillOpacity: 0.9 }}
          eventHandlers={{
            mouseover: () => showPreview(cluster.key),
            mouseout: () => scheduleClose(cluster.key),
            // En móviles: un toque muestra la lista, nunca cambia el zoom.
            click: () => showPreview(cluster.key),
          }}>
          <Tooltip permanent interactive direction="center" opacity={1}
            className={`sismo-cluster-label${previewKey === cluster.key ? ' sismo-cluster-label--active' : ''}`}>
            <span className="sismo-cluster-count">{cluster.events.length}</span>
            {previewKey === cluster.key && <div
              className={`sismo-cluster-preview${previewVisible ? ' is-visible' : ' is-closing'}`}
              onMouseEnter={() => showPreview(cluster.key)}
              onMouseLeave={() => scheduleClose(cluster.key)}
              onClick={event => event.stopPropagation()}
              role="group"
              aria-label={`Resumen de ${cluster.events.length} epicentros próximos`}>
              <strong className="block text-sm">{cluster.events.length} epicentros próximos</strong>
              <p className="mt-1 text-xs opacity-80">Agrupación visual; no representa una zona de impacto.</p>
              <ul className="mt-2 max-h-48 space-y-1 overflow-y-auto">
                {cluster.events.slice(0, 20).map(event => <li key={event.id}>
                  <button type="button"
                    className="flex w-full items-center gap-2 rounded px-1 py-1 text-left text-xs hover:bg-panel-alt focus-visible:outline-2 focus-visible:outline-accent"
                    onClick={() => { cancelClose(); setPreviewKey(null); setPreviewVisible(false); onSelect(event.properties.external_id); }}>
                    <span aria-hidden="true" className="h-2.5 w-2.5 shrink-0 rounded-full"
                      style={{ backgroundColor: magnitudeColor(event.properties.magnitude) }}/>
                    <span>{peruDate(event.properties.occurred_at, true)} · M{event.properties.magnitude?.toFixed(1) ?? '—'}</span>
                  </button>
                </li>)}
              </ul>
              {cluster.events.length > 20 && <p className="mt-2 text-xs opacity-80">20 de {cluster.events.length} resultados. Amplía con la rueda para separar los demás.</p>}
            </div>}
          </Tooltip>
        </CircleMarker>)}
    {/* Marcador seleccionado superpuesto: conserva el grupo y sus recuentos. */}
    {selectedFeature && selectedInGroup && <Epicenter key={`selected:${selectedFeature.id}`}
      feature={selectedFeature} focused autoZoom={selectedId === dashboardTargetId}
      liveFallback={selectedFeature.id.startsWith('igp-live-')}
      onClose={selectedId !== dashboardTargetId ? () => onSelect(null) : undefined}/>}
  </>;
}

/** Semáforo fijo por magnitud; no utiliza colores dinámicos del tema UI. */
function MagnitudeLegend() {
  const entries = [
    { label: 'M < 4.5', color: MAGNITUDE_COLORS.low },
    { label: 'M 4.5–5.9', color: MAGNITUDE_COLORS.medium },
    { label: 'M > 5.9', color: MAGNITUDE_COLORS.high },
    { label: 'Sin dato', color: MAGNITUDE_COLORS.unknown },
  ];
  return <div className="border-b border-border-ui bg-panel-alt px-4 py-3 text-xs text-main" aria-label="Leyenda de magnitudes observadas">
    <p className="mb-2 font-semibold">Leyenda por magnitud</p>
    <div className="flex flex-wrap gap-x-5 gap-y-2">
      {entries.map(entry => <div key={entry.label} className="flex items-center gap-2">
        <span className="inline-block h-4 w-4 shrink-0 rounded-full border-2"
          style={{ backgroundColor: entry.color, borderColor: entry.color }}/>
        <span>{entry.label}</span>
      </div>)}
    </div>
    <p className="mt-2 text-[10px] text-muted">Los colores identifican rangos de magnitud, no daños o intensidad. Los círculos numerados indican cantidad de epicentros.</p>
  </div>;
}

/** Nombre de capa activa de Leaflet; OpenStreetMap solo proporciona el fondo. */
function ActiveLayerTracker({ onChange }: { onChange: (name: string) => void }) {
  useMapEvents({ baselayerchange: event => onChange(event.name) });
  return null;
}

function localDateTime(utc: string | null): string {
  if (!utc || Number.isNaN(Date.parse(utc))) return 'No disponible';
  return new Date(utc).toLocaleString('es-PE', {
    timeZone: 'America/Lima', dateStyle: 'short', timeStyle: 'short',
  });
}

export default function Page() {
  const { filters, revision, refresh } = useAnalyticsFilters();
  const effectiveFilters = useMemo(() => withCurrentPeruMonth(filters), [filters, revision]);
  const [params, setParams] = useSearchParams();
  const location = useLocation();
  const targetId = params.get('igp_event');
  const igpTarget = useIGPFeed('recent', Boolean(targetId));
  const [dataset, setDataset] = useState<GeoDataset | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [layerName, setLayerName] = useState('OpenStreetMap');
  const [department, setDepartment] = useState('');
  const [boundary, setBoundary] = useState<DepartmentBoundary | null>(null);
  const [boundaryError, setBoundaryError] = useState('');
  const [loadingBoundary, setLoadingBoundary] = useState(false);
  const departmentName = PERU_DEPARTMENTS.find(([code]) => code === department)?.[1];
  // Obtiene la geometría referencial desde el snapshot local del backend.
  // Si falta cartografía válida, no reemplazamos el polígono por un rectángulo.
  useEffect(() => {
    const controller = new AbortController();
    setBoundary(null); setBoundaryError('');
    if (!department) { setLoadingBoundary(false); return () => controller.abort(); }
    setLoadingBoundary(true);
    getDepartmentBoundary(department, controller.signal)
      .then(value => {
        // Verifica que el servicio tenga coordenadas utilizables antes de mostrarlas.
        departmentBounds(value);
        if (!controller.signal.aborted) setBoundary(value);
      })
      .catch((reason: unknown) => {
        if (!controller.signal.aborted) setBoundaryError(reason instanceof Error ? reason.message : 'Error de límites');
      })
      .finally(() => { if (!controller.signal.aborted) setLoadingBoundary(false); });
    return () => controller.abort();
  }, [department]);
  // Reducir el universo consultado con una caja de SQL, luego recortar por el
  // polígono auténtico, con islas y huecos, antes de dibujar los puntos.
  const departmentQueryFilters = useMemo(() => {
    if (!department || !boundary || boundary.department !== department) return effectiveFilters;
    // Un departamento sustituye otros recortes geográficos; jamás enviar
    // radio + rectángulo simultáneamente al backend (sería HTTP 422).
    const {min_lat: _a, max_lat: _b, min_lon: _c, max_lon: _d,
      center_lat: _e, center_lon: _f, radius_km: _g, ...otherFilters} = effectiveFilters;
    void [_a, _b, _c, _d, _e, _f, _g];
    return { ...otherFilters, ...departmentBounds(boundary) };
  }, [effectiveFilters, department, boundary]);
  const [lastConsultation, setLastConsultation] = useState<string | null>(null);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [manualFocusId, setManualFocusId] = useState<string | null>(null);
  const [accessiblePage, setAccessiblePage] = useState(1);
  const selectedId = manualFocusId ?? targetId;
  const isRadial = effectiveFilters.radius_km != null && effectiveFilters.center_lat != null && effectiveFilters.center_lon != null;
  const isRectangular = effectiveFilters.min_lat != null && effectiveFilters.max_lat != null
    && effectiveFilters.min_lon != null && effectiveFilters.max_lon != null;

  // La hora del proveedor no está disponible como SLA: mostramos ingesta real.
  useEffect(() => {
    const controller = new AbortController();
    getDashboardOperations(controller.signal)
      .then(data => { if (!controller.signal.aborted) setLastSync(data.last_success_at); })
      .catch(() => { if (!controller.signal.aborted) setLastSync(null); });
    return () => controller.abort();
  }, [revision]);

  // Una sola fuente visible: catálogo IGP persistido y filtrado por mes peruano.
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true); setError(''); setDataset(null);
    if (department && (!boundary || boundary.department !== department)) {
      setLoading(false);
      return () => controller.abort();
    }
    getMapEvents(departmentQueryFilters, controller.signal)
      .then(data => { if (!controller.signal.aborted) { setDataset(data); setLastConsultation(new Date().toISOString()); } })
      .catch((cause: unknown) => {
        if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : 'No se pudo consultar el mapa');
      })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [departmentQueryFilters, revision, department, boundary]);

  // react-router conserva el reporte pulsado durante la transición. Si el IGP
  // cambia su listado reciente durante la navegación, ese dato sigue disponible.
  const selectedLive = useMemo(() => {
    const candidate = (location.state as { igpReport?: IGPEvent } | null)?.igpReport;
    if (candidate && candidate.external_id === targetId && Number.isFinite(candidate.latitude) && Number.isFinite(candidate.longitude)) return candidate;
    return (igpTarget.data?.items ?? []).find(item => item.external_id === targetId && Number.isFinite(item.latitude) && Number.isFinite(item.longitude));
  }, [location.state, igpTarget.data, targetId]);
  const { features, fallback, displayedCatalog } = useMemo(() => {
    const catalog = (dataset?.features ?? []).filter(feature =>
      Number.isFinite(feature.geometry.coordinates[0]) &&
      Number.isFinite(feature.geometry.coordinates[1]) &&
      matchesPeruPeriod(feature.properties.occurred_at, effectiveFilters) &&
      (!department || (boundary !== null && pointInDepartment(feature.geometry.coordinates, boundary))));
    const exists = Boolean(targetId && catalog.some(feature => feature.properties.external_id === targetId));
    // No sumar el reporte live al conjunto de métricas ni duplicar el mismo ID.
    const extra = targetId && !exists && selectedLive ? [asLiveFeature(selectedLive)] : [];
    return { features: [...catalog, ...extra], fallback: extra.length > 0, displayedCatalog: catalog.length };
  }, [dataset, effectiveFilters, targetId, selectedLive, department, boundary]);
  const focused = Boolean(selectedId && features.some(feature => feature.properties.external_id === selectedId));
  const listPageSize = 18;
  const totalAccessiblePages = Math.max(1, Math.ceil(features.length / listPageSize));
  const accessibleFeatures = features.slice((accessiblePage - 1) * listPageSize, accessiblePage * listPageSize);
  useEffect(() => setAccessiblePage(1), [effectiveFilters, dataset]);
  // El enlace desde Dashboard debe prevalecer frente a una selección manual antigua.
  useEffect(() => setManualFocusId(null), [targetId]);
  const unresolved = Boolean(targetId && !focused && !loading && !igpTarget.loading);

  function clearFocus() {
    const next = new URLSearchParams(params);
    next.delete('igp_event');
    setManualFocusId(null);
    setParams(next, { replace: true });
  }

  return <div className="space-y-5">
    <header className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.18em] text-accent">Epicentros observados · IGP/CENSIS</p>
        <h1 className="mt-1 text-3xl font-bold text-main">Mapa sísmico</h1>
        <p className="mt-1 text-sm text-muted">Mes actual de Perú por defecto. Cambia el período o la zona desde los mismos filtros del Dashboard.</p>
      </div>
      <FilterBar currentMonthDefault departmentSelection={{ value: department, onChange: setDepartment }} />
    </header>

    {boundaryError && <p role="alert" className="rounded-lg border border-rose-400 p-3 text-sm text-rose-600 dark:text-rose-300">
      {boundaryError}. No se aplicará un filtro departamental aproximado. Prueba otra vez o utiliza el filtro por radio.
    </p>}
    {error && <p role="alert" className="rounded-lg border border-rose-400 p-3 text-sm text-rose-600 dark:text-rose-300">{error}. Comprueba FastAPI y Supabase.</p>}
    {targetId && <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border-ui bg-panel-alt p-3 text-sm text-main">
      <div>
        <strong>Epicentro seleccionado: {targetId}</strong>
        {focused && <p className="mt-1 text-xs text-muted">Se ha centrado el mapa y abierto su ficha automáticamente.{fallback ? ' El reporte en vivo todavía no aparece entre los puntos consultados.' : ''}</p>}
        {igpTarget.loading && !focused && <p className="mt-1 text-xs text-muted">Localizando reporte en IGP…</p>}
        {unresolved && <p role="status" className="mt-1 text-xs text-muted">No se encontró este ID en el catálogo filtrado ni en los reportes recientes del IGP. Prueba ampliar las fechas o actualizar la fuente.</p>}
      </div>
      <button type="button" onClick={clearFocus} className="inline-flex items-center gap-1.5 rounded-lg border border-border-ui bg-panel px-3 py-2 text-xs font-medium text-main hover:bg-page"><X size={14}/> Quitar selección</button>
    </div>}

    {department && <p className="rounded-lg border border-border-ui bg-panel-alt p-3 text-sm text-main">
      Departamento: <strong>{departmentName}</strong> · {loadingBoundary ? 'Consultando límites referenciales…' : boundary ? 'Filtro por polígono administrativo referencial aplicado' : 'Esperando límites'}.
      {' '}Solo se consideran epicentros situados dentro del polígono terrestre; un sismo frente a la costa puede quedar fuera.
    </p>}
    <p role="status" className="flex flex-wrap items-center gap-2 text-xs text-muted">
      <span className="rounded-md border border-border-ui bg-panel px-2.5 py-1.5 text-main">
        Período IGP: {civilDate(effectiveFilters.start_time)} – {civilDate(effectiveFilters.end_time)} (Perú)
      </span>
      <span>«Limpiar» en los filtros restablece el mes actual.</span>
    </p>

    <section aria-label="Mapa y filtros aplicados" className="flex flex-col gap-4 xl:flex-row">
      <article className="min-w-0 flex-1 overflow-hidden rounded-2xl border border-border-ui bg-panel shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border-ui p-4">
          <div>
            <h2 className="flex items-center gap-2 font-semibold text-main"><MapPin size={17} className="text-accent"/> Epicentros IGP/CENSIS</h2>
            <p className="mt-1 text-xs text-muted">Catálogo sincronizado · Fecha civil de Perú · Fuente exclusiva IGP</p>
          </div>
          <div className="flex items-center gap-3 text-xs text-muted">
            {loadingBoundary ? 'Consultando límite…' : loading ? 'Consultando…' : department ? `${displayedCatalog} epicentros dentro de ${departmentName ?? department}` : `${displayedCatalog} de ${dataset?.total ?? 0} eventos del período`}
            <button type="button" onClick={() => { refresh(); if (targetId) igpTarget.refresh(); }}
              className="inline-flex items-center gap-1 rounded-lg border border-border-ui px-2 py-1.5 text-main hover:bg-panel-alt" aria-label="Actualizar mapa IGP"><RefreshCw size={13}/> Actualizar</button>
          </div>
        </div>
        {department && dataset?.truncated && <p role="status" className="border-b border-border-ui bg-panel-alt px-4 py-2 text-sm text-main">El área del departamento devuelve más de 1.000 eventos en el período; acota las fechas para obtener un recorte completo.</p>}
        {dataset?.truncated && <p className="border-b border-border-ui bg-panel-alt px-4 py-2 text-sm text-main">Se muestran los {dataset.returned} epicentros más recientes del período; ajusta los filtros para consultar otros.</p>}
        {fallback && <p className="border-b border-border-ui bg-panel-alt px-4 py-2 text-xs text-main">El punto seleccionado procede de IGP en vivo y no se agrega al recuento del catálogo mensual. Si está fuera del período filtrado, solo se muestra por haberlo seleccionado explícitamente.</p>}
        {/* Las capas de Leaflet pueden usar z-index >= 1000. Aislarlas dentro de
            esta superficie impide que tapen el modal compartido y el sidebar móvil. */}
        <div className="relative isolate z-0 h-[540px] w-full bg-panel-alt">
          <MapContainer center={[-9.19, -75]} zoom={5} scrollWheelZoom={true} wheelDebounceTime={65}
            className="sismo-leaflet-map relative isolate z-0 h-full w-full"
            style={{ height: '100%', width: '100%', isolation: 'isolate', zIndex: 0, background: 'var(--ui-panel-alt)' }}>
            <LayersControl position="topright">
              <LayersControl.BaseLayer checked name="OpenStreetMap">
                <TileLayer url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>' maxZoom={17}/>
              </LayersControl.BaseLayer>
              <LayersControl.BaseLayer name="Sin mapa base">
                <LayerGroup />
              </LayersControl.BaseLayer>
            </LayersControl>
            <ActiveLayerTracker onChange={setLayerName}/>
            {boundary && department && boundary.department === department && boundary.features.flatMap((feature, fi) => {
              const polygons = feature.geometry.type === 'Polygon'
                ? [feature.geometry.coordinates] : feature.geometry.coordinates;
              return polygons.map((polygon, pi) => <Polygon key={`department-${fi}-${pi}`}
                positions={polygon.map(ring => ring.map(([lon, lat]) => [lat, lon] as [number, number]))}
                pathOptions={{ color: '#0891b2', weight: 2, dashArray: '5 4', fillOpacity: 0.03 }} />);
            })}
            {isRadial && <Circle center={[effectiveFilters.center_lat!, effectiveFilters.center_lon!]}
              radius={effectiveFilters.radius_km! * 1000}
              pathOptions={{ color: '#0891b2', weight: 2, dashArray: '6 5', fillOpacity: 0.04 }}/>} 
            {isRectangular && <Rectangle
              bounds={[[effectiveFilters.min_lat!, effectiveFilters.min_lon!], [effectiveFilters.max_lat!, effectiveFilters.max_lon!]]}
              pathOptions={{ color: '#0891b2', weight: 2, dashArray: '6 5', fillOpacity: 0.04 }}/>} 
            <FitMarkers features={features} focused={focused}
              defaultCenter={isRadial ? [effectiveFilters.center_lat!, effectiveFilters.center_lon!] : undefined}
              defaultBounds={department && boundary ? (() => {
                const bounds = departmentBounds(boundary);
                return [[bounds.min_lat, bounds.min_lon], [bounds.max_lat, bounds.max_lon]] as [[number, number], [number, number]];
              })() : isRectangular ? [
                [effectiveFilters.min_lat!, effectiveFilters.min_lon!],
                [effectiveFilters.max_lat!, effectiveFilters.max_lon!],
              ] : undefined}/>
            <ClusteredMarkers features={features} selectedId={selectedId} dashboardTargetId={targetId} onSelect={setManualFocusId}/>
          </MapContainer>
          {!loading && features.length === 0 && !error && !boundaryError && !loadingBoundary && <div className="pointer-events-none absolute left-1/2 top-4 z-10 w-max max-w-[90%] -translate-x-1/2 rounded-lg bg-panel p-3 text-center text-sm text-main shadow-lg">No hay epicentros para los filtros actuales.</div>}
        </div>
        <MagnitudeLegend/>
        <div className="flex flex-wrap items-center gap-4 px-4 py-3 text-xs text-muted">
          <span className="inline-flex items-center gap-1"><Layers size={13}/> Capa activa: {layerName}</span>
          <span className="inline-flex items-center gap-1"><CalendarClock size={13}/> Consulta: {localDateTime(lastConsultation)}</span>
          <span>Última ingesta IGP: {localDateTime(lastSync)}</span>
          <span>El color indica el rango de magnitud, no el peligro ni la intensidad; el tamaño es secundario.</span>
          <span>Grupos numerados: hover para ver el resumen (toque en móviles); rueda para acercar.</span>
          <span>Rueda sobre el mapa: zoom · Fuera del mapa: desplazamiento de página.</span>
          <span>Solo epicentros, sin zonas estimadas de impacto.</span>
          <a href={IGP_OFFICIAL_URL} target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">Fuente oficial IGP</a>
        </div>
      </article>
      <AppliedFiltersAside filters={effectiveFilters} sampleSize={department ? displayedCatalog : dataset?.total}
        lastSync={lastSync} geoDescription={department ? `${departmentName} (límite referencial; epicentros terrestres)` : undefined}/>
    </section>
    <details className="rounded-xl border border-border-ui bg-panel p-4 text-main">
      <summary className="flex cursor-pointer items-center gap-2 text-sm font-semibold"><List size={16}/> Lista accesible de epicentros ({features.length})</summary>
      <p className="mt-2 text-xs text-muted">Selecciona un evento para centrar el mapa y abrir la misma ficha de detalles. Los registros se presentan por fecha.</p>
      <ol className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {accessibleFeatures.map(feature => <li key={feature.id}>
          <button type="button" onClick={() => setManualFocusId(feature.properties.external_id)}
            className="w-full rounded-lg border border-border-ui bg-panel-alt p-2 text-left text-xs text-main hover:border-accent focus-visible:outline-2 focus-visible:outline-accent">
            <span className="block font-semibold">M{feature.properties.magnitude?.toFixed(1) ?? '—'} · {peruDate(feature.properties.occurred_at, true)}</span>
            <span className="mt-1 block text-muted">{feature.properties.place || 'Sin ubicación publicada'}</span>
          </button>
        </li>)}
      </ol>
      {accessibleFeatures.length === 0 && <p className="mt-2 text-sm text-muted">No hay registros en el período seleccionado.</p>}
      {features.length > 0 && <nav aria-label="Páginas de epicentros" className="mt-3 flex items-center justify-between gap-2 text-xs">
        <button type="button" disabled={accessiblePage === 1}
          onClick={() => setAccessiblePage(n => Math.max(1, n - 1))}
          className="rounded-lg border border-border-ui px-3 py-2 disabled:opacity-40">Anterior</button>
        <span>Página {accessiblePage} de {totalAccessiblePages}</span>
        <button type="button" disabled={accessiblePage >= totalAccessiblePages}
          onClick={() => setAccessiblePage(n => Math.min(totalAccessiblePages, n + 1))}
          className="rounded-lg border border-border-ui px-3 py-2 disabled:opacity-40">Siguiente</button>
      </nav>}
    </details>
  </div>;
}
